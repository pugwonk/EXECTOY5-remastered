using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;

public class Executive_Toy:Form
{
  // Grains of sand in the tank
  const ushort sand = 7800;	//8015;

  // Drops of water in the tank
  const ushort water = 2800;	//3487;

  // How zoom multiplier for the tank
  const int zoom = 2;

  ushort location;

  bool flipTank = false;
  bool randomizeWater = false;

  Random rand = new Random ();
    System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer ();

  // These arrays are actually structs, the first byte is the colorPalette index, the next two bytes are the location of the pixel.
    byte[] sandpos = new byte[sand * 3];
    byte[] waterpos = new byte[water * 3];

  // This is basically the Video Memory buffer, 320x200 bytes
  //13h Mode (256 color) Video Memory starts at $A000:$0000
  // has resolution 320x200
  // and each pixel represented by a byte indicating its color
    byte[] Mem = new byte[0xFB41];	//Should be 0xFA00 in size, but weird stuff is going on outside of that range

    System.Drawing.Bitmap bm = new System.Drawing.Bitmap (320, 200);
    Color[] colorPalette = new Color[41];

  public void AnimateTheLot ()
  {
    //Console.WriteLine("AnimateTheLot");

    animate_sand ();
    animate_water ();

    if (flipTank)
    {
      FlipTank ();
      flipTank = false;
    }

    if (randomizeWater)
    {
      RandomizeWater ();
      randomizeWater = false;
    }

    this.Invalidate ();
  }

  private void animate_sand ()
  {
    // Sand generally wants to sink.  It tries to go straight down, but will go diagonally down to the left or right if the pixel immediately beneath it is filled.  If none of these pixels are available then the sand doesn't move.

    ////Console.WriteLine("Animate_Sand");
    ushort SI = 0;

    // update_all_dots
    for (int CX = sand; CX > 0; CX--)
    {
      ushort AX = sandpos[SI];		// Colour
      SI++;

      ushort currentPosition = (ushort) (sandpos[SI] | (sandpos[SI + 1] << 8));	// Current position
      Mem[currentPosition] = 0;		// Clear it, try MOVSB or whatever

      if (Mem[currentPosition + 320] == 0)	// Gap directly underneath?
      {
          currentPosition += 320;		// Fill it!
      }
      // Nope, try for one on the left
      if (Mem[currentPosition + 319] == 0)	// Gap to the left underneath?
      {
          currentPosition += 319;		// Tara, gap
      }

      if (currentPosition + 321 < Mem.Length && Mem[currentPosition + 321] == 0)	 // Gap to right (PPLLLEEAAASSSEEEE!!!)
      {
          currentPosition += 321;
      }
      // @give_up:
      Mem[currentPosition] = Lo (AX);	// Plot it to me, pal
      sandpos[SI] = Lo (currentPosition);	//  Store for posterity (and next shot)
      sandpos[SI + 1] = Hi (currentPosition);
      SI += 2;
    }
  }

  private void animate_water ()
  {
    // Water generally wants to move up.  It will move to the immediate left or right if only one of them is available.  Otherwise it doesn't move.

    ////Console.WriteLine("Animate_Water");
    ushort SI = 0;

    // @update_all_drops:
    for (int CX = water; CX > 0; CX--)
    {
      ushort AX = waterpos[SI];
      SI++;

      ushort DI = (ushort) (waterpos[SI] | (waterpos[SI + 1] << 8));;
      Mem[DI] = 0;

      if (DI >= 320 && Mem[DI - 320] == 0)
      {
          DI -= 320;
      } else if ((DI > 0 && Mem[DI - 1] == 0) && (DI < Mem.Length - 1 && Mem[DI + 1] != 0))	//try left
      {
          DI--;
      } else if ((DI < Mem.Length - 1 && Mem[DI + 1] == 0) && (DI > 0 && Mem[DI - 1] != 0))	// try right
      {
          DI++;
      }

      // give_up:
      Mem[DI] = Lo (AX);
      waterpos[SI] = Lo (DI);
      waterpos[SI + 1] = Hi (DI);
      SI += 2;
    }
  }

  private byte Hi (ushort w)
  {
    //return the high order byte
    return (byte) (0x00FF & (w >> 8));
  }

  private byte Lo (ushort w)
  {
    //return the low order byte
    return (byte) (0x00FF & w);
  }

  public static void Main ()
  {
    Application.Run (new Executive_Toy ());
  }

  public Executive_Toy ()
  {
    Init ();

    myTimer.Tick += new EventHandler (TimerEventProcessor);

    myTimer.Interval = 1000 / 30;
    myTimer.Start ();
  }

  private void TimerEventProcessor (Object myObject, EventArgs myEventArgs)
  {
    myTimer.Stop ();
    AnimateTheLot ();
    myTimer.Enabled = true;
  }

  private void Init ()
  {
    //Turn on double buffering
    this.SetStyle (ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);

    this.Paint += new PaintEventHandler (Executive_Toy_Paint);
    this.Height = 200 * zoom + SystemInformation.CaptionHeight + 2 * SystemInformation.Border3DSize.Height;
    this.Width = 320 * zoom + 2 * SystemInformation.Border3DSize.Width;

    //Initialize our color palette
    //Background color is at index 0
    SetRGBPalette (0, 0, 0, 0);

    // Sand colors are from indices 1 - 30
    for (int paletteIndex = 1; paletteIndex <= 30; paletteIndex++)
    {
      SetRGBPalette (paletteIndex, 30 + paletteIndex, 30 + paletteIndex, 0);
    }

    // Water colors are from indices 31 - 40;
    for (int paletteIndex = 1; paletteIndex <= 10; paletteIndex++)
    {
      SetRGBPalette (30 + paletteIndex, 0, 0, 30 + (paletteIndex * 3));
    }

    for (int setup = 1; setup <= sand; setup++)
    {
      // Pick a random Sand color for each sand position
      sandpos[setup * 3 - 3] = (byte) rand.Next (31);

      // Randomly pick a pixel in the top half of the region that is blank
      do
      {
          location = (ushort) rand.Next (32000);
      } while (Mem[location] != 0);

      Mem[location] = sandpos[(setup * 3) - 3];
      sandpos[(setup * 3) - 2] = Lo (location);
      sandpos[(setup * 3) - 1] = Hi (location);
    }

    for (int setup = 1; setup <= water; setup++)
    {
      // Pick a random Water color for each position
      waterpos[setup * 3 - 3] = (byte) rand.Next (31, 41);	// colour

      // Randomly pick a blank pixel in the bottom ~1/5 of the screen.
      do
      {
          location = (ushort) (0xFA00 - rand.Next (12288));
      } while (Mem[location] != 0);

      Mem[location] = waterpos[(setup * 3) - 3];
      waterpos[(setup * 3) - 2] = Lo (location);
      waterpos[(setup * 3) - 1] = Hi (location);
    }

    // Create a row of padding at the end to make sure sand/water doesn't fall out of the tank
    for (int bumbar = 1; bumbar <= 320; bumbar++)
    {
      Mem[0xFA00 + bumbar] = 1;
    }
  }

  private void Executive_Toy_Paint (object sender, PaintEventArgs e)
  {
    ////Console.WriteLine("Paint!");
    Graphics graphics = e.Graphics;

    for (int y = 0; y < 200; y++)
    {
      for (int x = 0; x < 320; x++)
      {
          int color = Mem[y * 320 + x];
          bm.SetPixel (x, y, colorPalette[color]);
      }
    }

    graphics.DrawImage (bm, 0, 0, 320 * zoom, 200 * zoom);
  }

  public void SetRGBPalette (int colorIndex, int red, int green, int blue)
  {
    colorPalette[colorIndex] = Color.FromArgb (red, green, blue);
  }

  private void FlipTank ()
  {
    // Turn the whole tank upside down.
    for (int setup = 1; setup <= sand; setup++)
    {
      location = (ushort) (sandpos[(setup * 3) - 2] + 256 * sandpos[(setup * 3) - 1]);
      Mem[location] = 0;

      //Pick the diametrically opposite location
      location = (ushort) (64000 - location);

      Mem[location] = sandpos[(setup * 3) - 3];
      sandpos[(setup * 3) - 2] = Lo (location);
      sandpos[(setup * 3) - 1] = Hi (location);
    }

    for (int setup = 1; setup <= water; setup++)
    {
      location = (ushort) (waterpos[(setup * 3) - 2] + 256 * waterpos[(setup * 3) - 1]);
      Mem[location] = 0;

      //Pick the diametrically opposite location
      location = (ushort) (64000 - location);

      Mem[location] = waterpos[(setup * 3) - 3];
      waterpos[(setup * 3) - 2] = Lo (location);
      waterpos[(setup * 3) - 1] = Hi (location);
    }
  }

  private void RandomizeWater ()
  {
    // Randomly rearrange 100 water drops
    for (int zap = 1; zap <= 100; zap++)
    {
      int index = (ushort) (rand.Next (1, water + 1));
      location = (ushort) (waterpos[(index * 3) - 2] + 256 * waterpos[(index * 3) - 1]);
      Mem[location] = 0;

      // Randomly pick a new location until we find a blank one
      do
      {
          location = (ushort) rand.Next (64000);
      } while (Mem[location] != 0);

      Mem[location] = waterpos[(index * 3) - 3];
      waterpos[(index * 3) - 2] = Lo (location);
      waterpos[(index * 3) - 1] = Hi (location);
    }
  }

  protected override void OnKeyDown (KeyEventArgs kea)
  {
    switch (kea.KeyCode)
    {
    case Keys.Q:
      Console.WriteLine ("Quit!!");
      Application.Exit ();
      break;
    case Keys.S:
      Console.WriteLine ("Flip Tank!!");
      flipTank = true;
      break;
    case Keys.W:
      Console.WriteLine ("Randomize Water!!");
      randomizeWater = true;
      break;
    }
  }
}
