using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;

public class Executive_Toy : Form
{
  // Grains of sand in the tank
  const ushort sand = 7800;  //8015;

  // Drops of water in the tank
  const ushort water = 2800;	//3487;

  // How zoom multiplier for the tank
  const int zoom = 2;

   const int TankWidth = 320;
   const int TankHeight = 200;
   int[,] bitMap;

    System.Drawing.Bitmap bm = new System.Drawing.Bitmap (TankWidth, TankHeight);
    Color[] colorPalette = new Color[41];

    bool flipTank = false;
    bool randomizeWater = false;

    Random rand = new Random ();
    System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer ();

    grain[] sandpos = new grain[sand];
    grain[] waterpos = new grain[water];

  private class grain
  {
       public int colorIndex;
       public int x;
       public int y;
   };

  public void AnimateTheLot ()
  {
    //Console.WriteLine("AnimateTheLot");

    animate_sand ();
    animate_water ();

    if (flipTank)
    {
      FlipTank ();
      flipTank = false;
    }

    if (randomizeWater)
    {
      RandomizeWater ();
      randomizeWater = false;
    }

    this.Invalidate ();
  }

  private void animate_sand ()
  {
    // Sand generally wants to sink.  It tries to go straight down, but will go diagonally down to the left or right if the pixel immediately beneath it is filled.  If none of these pixels are available then the sand doesn't move.

    ////Console.WriteLine("Animate_Sand");
    for (int i = 0; i < sand; i++)
    {
      grain currentGrain = sandpos[i];

      bitMap[currentGrain.x, currentGrain.y] = 0;

      if (currentGrain.y < TankHeight - 1 && bitMap[currentGrain.x, currentGrain.y+1] == 0)	 // Gap directly underneath?
      {
          currentGrain.y++;
      }

       if (currentGrain.x > 0 && currentGrain.y < TankHeight - 1 && bitMap[currentGrain.x-1, currentGrain.y+1] == 0)	// Gap to the left underneath?
      {
          currentGrain.x--;
          currentGrain.y++;
      }

      if (currentGrain.x < TankWidth - 1 && currentGrain.y < TankHeight - 1 &&
        bitMap[currentGrain.x+1, currentGrain.y+1] == 0)	// Gap to right (PPLLLEEAAASSSEEEE!!!)
      {
          currentGrain.x++;
          currentGrain.y++;
      }

      bitMap[currentGrain.x, currentGrain.y] = currentGrain.colorIndex;	// Plot it to me, pal
    }
  }

  private void animate_water ()
  {
    // Water generally wants to move up.  It will move to the immediate left or right if only one of them is available.  Otherwise it doesn't move.

    ////Console.WriteLine("Animate_Water");
    for (int i = 0; i < water; i++)
    {
      grain currentGrain = waterpos[i];

     bitMap[currentGrain.x, currentGrain.y] = 0;

      if (currentGrain.y > 1 && bitMap[currentGrain.x, currentGrain.y - 1] == 0)
      {
          currentGrain.y--;
      } else if (currentGrain.x > 0 &&
                    bitMap[currentGrain.x - 1, currentGrain.y] == 0 &&
                    currentGrain.x < TankWidth-1 &&
                    bitMap[currentGrain.x + 1, currentGrain.y] != 0) 	//try left
      {
          currentGrain.x--;
      } else if (currentGrain.x < TankWidth - 1 &&
                    bitMap[currentGrain.x + 1, currentGrain.y] == 0 &&
                    currentGrain.x > 0 &&
                    bitMap[currentGrain.x - 1, currentGrain.y] != 0)	// try right
      {
          currentGrain.x--;
      }

        bitMap[currentGrain.x, currentGrain.y] = currentGrain.colorIndex;
    }
  }

  public static void Main ()
  {
    Application.Run (new Executive_Toy ());
  }

  public Executive_Toy ()
  {
    //Turn on double buffering
    this.SetStyle (ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);

    this.Paint += new PaintEventHandler (Executive_Toy_Paint);
    this.Height = TankHeight * zoom + SystemInformation.CaptionHeight + 2 * SystemInformation.Border3DSize.Height;
    this.Width = TankWidth * zoom + 2 * SystemInformation.Border3DSize.Width;

    InitializePalette();

    Init();

    myTimer.Tick += new EventHandler (TimerEventProcessor);

    myTimer.Interval = 1000 / 30;
    myTimer.Start ();
  }

  private void TimerEventProcessor (Object myObject, EventArgs myEventArgs)
  {
    myTimer.Stop ();
    AnimateTheLot ();
    myTimer.Enabled = true;
  }

private void InitializePalette()
{
    //Background color is at index 0
    SetRGBPalette (0, 0, 0, 0);

    // Sand colors are from indices 1 - 30
    for (int paletteIndex = 1; paletteIndex <= 30; paletteIndex++)
    {
      SetRGBPalette (paletteIndex, 30 + paletteIndex, 30 + paletteIndex, 0);
    }

    // Water colors are from indices 31 - 40;
    for (int paletteIndex = 1; paletteIndex <= 10; paletteIndex++)
    {
      SetRGBPalette (30 + paletteIndex, 0, 0, 30 + (paletteIndex * 3));
    }
}

  private void SetRGBPalette (int colorIndex, int red, int green, int blue)
  {
    colorPalette[colorIndex] = Color.FromArgb (red, green, blue);
  }

  private void Init ()
  {
      bitMap = new int[TankWidth, TankHeight];

    for (int i = 0; i < sand; i++)
    {
      // Pick a random Sand color for each sand position
      grain currentGrain = new grain();
      currentGrain.colorIndex= rand.Next (31);

      // Randomly pick a pixel in the top half of the region that is blank
      do
      {
          currentGrain.x = rand.Next(TankWidth);
          currentGrain.y = rand.Next(TankHeight/2);
      } while (bitMap[currentGrain.x, currentGrain.y] != 0);

      bitMap[currentGrain.x, currentGrain.y] = currentGrain.colorIndex;
      sandpos[i] = currentGrain;
    }

    for (int i = 0; i < water; i++)
    {
       grain currentGrain = new grain();

      // Pick a random Water color for each position
      currentGrain.colorIndex = rand.Next (31, 41);	

      // Randomly pick a blank pixel in the bottom ~1/5 of the screen.
      do
      {
          currentGrain.x = rand.Next(TankWidth);
          currentGrain.y = rand.Next((int)(0.80 * TankHeight), TankHeight);
      } while (bitMap[currentGrain.x, currentGrain.y] != 0);

      bitMap[currentGrain.x, currentGrain.y] = currentGrain.colorIndex;
      waterpos[i] = currentGrain;
    }
  }

  private void Executive_Toy_Paint (object sender, PaintEventArgs e)
  {
    ////Console.WriteLine("Paint!");
    Graphics graphics = e.Graphics;

    for (int y = 0; y < TankHeight; y++)
    {
      for (int x = 0; x < TankWidth; x++)
      {
          int color = bitMap[x, y];
          bm.SetPixel (x, y, colorPalette[color]);
      }
    }

    graphics.DrawImage (bm, 0, 0, TankWidth * zoom, TankHeight * zoom);
  }

  private void FlipTank ()
  {
    // Turn the whole tank upside down.
    for (int i = 0; i < sand; i++)
    {
      grain currentGrain = sandpos[i];
      bitMap[currentGrain.x, currentGrain.y] = 0;

      //Pick the diametrically opposite location
     currentGrain.x = TankWidth - currentGrain.x - 1;
     currentGrain.y = TankHeight - currentGrain.y - 1;

      bitMap[currentGrain.x, currentGrain.y] = currentGrain.colorIndex;
    }

    for (int i = 0; i < water; i++)
    {
      grain currentGrain = waterpos[i];
      bitMap[currentGrain.x, currentGrain.y] = 0;

      //Pick the diametrically opposite location
     currentGrain.x = TankWidth - currentGrain.x - 1;
     currentGrain.y = TankHeight - currentGrain.y - 1;

      bitMap[currentGrain.x, currentGrain.y] = currentGrain.colorIndex;
    }
  }

  private void RandomizeWater ()
  {
    // Randomly rearrange 100 water drops
    for (int zap = 0; zap < 100; zap++)
    {
      int index = rand.Next (water);
      grain currentGrain = waterpos[index];
      bitMap[currentGrain.x, currentGrain.y] = 0;

      // Randomly pick a new location until we find a blank one
      do
      {
          currentGrain.x = rand.Next(TankWidth);
          currentGrain.y = rand.Next(TankHeight);
      } while (bitMap[currentGrain.x , currentGrain.y] != 0);

      bitMap[currentGrain.x , currentGrain.y] = currentGrain.colorIndex;
    }
  }

  protected override void OnKeyDown (KeyEventArgs kea)
  {
    switch (kea.KeyCode)
    {
    case Keys.Q:
      Console.WriteLine ("Quit!!");
      Application.Exit ();
      break;
    case Keys.S:
      Console.WriteLine ("Flip Tank!!");
      flipTank = true;
      break;
    case Keys.W:
      Console.WriteLine ("Randomize Water!!");
      randomizeWater = true;
      break;
    case Keys.R:
        Init();
     break;
    }
  }
}
